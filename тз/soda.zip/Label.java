package ru.agentd;

public interface Label {
    Label copy();
}
