package ru.agentd;

public interface Soda {
    Soda copy();
}
