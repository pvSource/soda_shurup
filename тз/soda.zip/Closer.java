package ru.agentd;

public interface Closer {
    Closer copy();
}
